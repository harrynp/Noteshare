<div id="pageBottom">&copy;2015 Friendstr</div>
